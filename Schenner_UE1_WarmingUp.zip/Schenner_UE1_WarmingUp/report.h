//
// Created by Jakob Schenner on 11/28/19.
//

#ifndef WARMING_UP_CPP_REPORT_H
#define WARMING_UP_CPP_REPORT_H

bool reportOpenFile(char *source);
bool reportReport();
bool reportCloseFile();

#endif //WARMING_UP_CPP_REPORT_H
